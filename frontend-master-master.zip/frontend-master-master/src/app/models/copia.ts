export interface copia{
    _id: string;
    pelicula: string,
    id_cinta: string;
    disponible: boolean;
}
