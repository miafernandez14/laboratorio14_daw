export interface socio {
    _id: string;
    nombre: string;
    direccion: string;
    telefono: number;
    fechaCreacion: Date;
    directorFavorito: string;
    actorFavorito: string;
    generoPreferido: string;
}