export interface pelicula{
    _id: string;
    titulo: string;
    genero: string;
    director: string;
    actores: string;
}